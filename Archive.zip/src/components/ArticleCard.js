import React from 'react';
import {Button, Card, Col, Container, Row} from "react-bootstrap";

const ArticleCard = () => {
    return (
        <>
            <Row className="mt-4 g-3">
                <Col lg={4}>
                    <Card className="shadow-sm h-100">
                        <Card.Img
                            role="button"
                            variant="top"
                            src="https://ic-cdn.flipboard.com/npr.org/d67fe1e9a13de4090a0133c3c40709c39b3df2af/_medium.webp"
                        />
                        <Card.Body>
                            <Card.Title role="button">
                                Why Egypt doesn't want Palestinians in Gaza to cross the border
                            </Card.Title>
                            <Card.Text className="small">
                                NPR - Scott Neuman
                            </Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
                <Col lg={4}>
                    <Card className="shadow-sm h-100">
                        <Card.Img
                            role="button"
                            variant="top"
                            src="https://ic-cdn.flipboard.com/npr.org/d67fe1e9a13de4090a0133c3c40709c39b3df2af/_medium.webp"
                        />
                        <Card.Body>
                            <Card.Title role="button">
                                Why Egypt doesn't want Palestinians in Gaza to cross the border
                            </Card.Title>
                            <Card.Text className="small">
                                NPR - Scott Neuman
                            </Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
                <Col lg={4}>
                    <Card className="shadow-sm h-100">
                        <Card.Img
                            role="button"
                            variant="top"
                            src="https://ic-cdn.flipboard.com/npr.org/d67fe1e9a13de4090a0133c3c40709c39b3df2af/_medium.webp"
                        />
                        <Card.Body>
                            <Card.Title role="button">
                                Why Egypt doesn't want Palestinians in Gaza to cross the border
                            </Card.Title>
                            <Card.Text className="small">
                                NPR - Scott Neuman
                            </Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </>
    );
};

export default ArticleCard;