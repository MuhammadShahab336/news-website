import React, {useState} from 'react';
import {Button, Col, Container, Row, Form} from "react-bootstrap";
import Collapse from 'react-bootstrap/Collapse';

const FilteringForm = ({ children }) => {
    const [open, setOpen] = useState(false);
    return (
        <>
            <Container fluid className="mt-5">
                <Row>
                    <Col lg={3}>
                        <Row
                            onClick={() => setOpen(!open)}
                            aria-controls="example-collapse-text"
                            aria-expanded={open}
                            role="button"
                            className="g-0 p-2 bg-light shadow-sm"
                        >
                            <Col>
                                <p className="fw-bold m-0">Category</p>
                            </Col>
                            <Col xs="auto">
                            <span className="d-block" style={{transform: 'rotateX(180deg)'}}>
                                ^
                            </span>
                            </Col>
                        </Row>
                        <Collapse in={open}>
                            <div id="example-collapse-text">
                                <Form className="p-2">
                                    {['checkbox 1', 'checkbox 2'].map((type) => (
                                        <div key={`default-${type}`} className="mb-3">
                                            <Form.Check // prettier-ignore
                                                type="checkbox"
                                                id={`default-${type}`}
                                                label={`default ${type}`}
                                            />
                                        </div>
                                    ))}
                                </Form>
                            </div>
                        </Collapse>
                    </Col>
                    <Col lg={9}>
                        <Row className="justify-content-end">
                            <Col lg={6}>
                                <Form.Group className="mb-0">
                                    <Form.Control type="search" placeholder="Search Article" />
                                </Form.Group>
                            </Col>
                            <Col lg={4}>
                                <Row className="gx-2 gy-0">
                                    <Col>
                                        <Form.Group className="mb-0">
                                            <Form.Control type="date" placeholder="Search Article" />
                                        </Form.Group>
                                    </Col>
                                    <Col xs="auto">
                                        <Button variant="primary">Search</Button>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                        {children}
                    </Col>
                </Row>
            </Container>
        </>
    );
};

export default FilteringForm;