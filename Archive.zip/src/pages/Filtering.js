import React from 'react';
import FilteringForm from "../components/FilteringForm";
import ArticleCard from "../components/ArticleCard";

const Filtering = () => {
    return (
        <>
            <FilteringForm>
                <ArticleCard />
            </FilteringForm>
        </>
    );
};

export default Filtering;